<b>SmoothScroll</b><br>
JS plugin to add smooth scroll effect to your website.

Add Jquery and SmoothScroll to your website.

How to add?
<ul>
  <li>
    Copy and paste the below to lines to your HTML code
    <ul>
      <li><code><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script></code></li>
      <li><code><script src="https://shahi9935.github.io/Smooth-Scroll/smoothScroll.js"></script></code></li>
    </ul>
  </li>
  <li>
    Add class of "sscroll" to the anchor tags on which you want to perform SmoothScroll on clicking.
    </li>
  </ul>
  
  See example at https://shahi9935.github.io/Smooth-Scroll/
